<?php include 'mustregister.php'; ?>
<html>
<head>

<?php include 'head.php'; ?>
</head>
	
<body>
<section id="banner">
	<section id="aboutus">
		<div class="title-text">
		<h1>About Us</h1>
		</div>
		
		<div class="aboutus-row">
			<div class="aboutus-col">
				<p>This page serves as a space for user to make report to the authorities about disaster happened near
				their location for further action.</p>
				
				<br><br><br><p></p>
			</div>
		</div>
	</section>
</section>


<?php include 'sideNav.php';?>
</body>
<html>